const ordersRouter = require("./orders.api");

module.exports = ordersRouter;