const productsRouter = require("./products.api");

module.exports = productsRouter;