/* Give the config parameters to establish database connectivity*/
module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "Ge@426759813",
    DB: "KeepNotes"
  };