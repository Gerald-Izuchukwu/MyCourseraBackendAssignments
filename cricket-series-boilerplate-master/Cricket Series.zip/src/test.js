// const result = Math.ceil(((40/12) * 100) / 100);
// console.log(result);

// const result = (40/12) + (0.01/12);
// console.log(result);

const numerator = 40;
const denominator = 12;
const result = Math.round((numerator / denominator + Number.EPSILON) * 100) / 100;
console.log(result);