const express = require('express')
const router = express.Router()
const mongoose = require('mongoose')
const axios = require('axios').default
require('../dbconfig/dbfile')
const MovieReview = require('../MovieReviews/movieReviewModel')
router.post('/', async (req, res) => {
  try {
    const newMovieReview = new MovieReview({
      userId : mongoose.Types.ObjectId(req.body.userId),
      movieId : mongoose.Types.ObjectId(req.body.movieId)
    })
    const data = await newMovieReview.save()
    if(data){
      res.status(200).send('success')
    }
  } catch (error) {
    console.log('error', error);
  }
})
 
//This get will retreive userid and its movie data
router.get('/:id', (req, res) => {
  MovieReview.findById(req.params.id).then((review)=>{
    if(review){
      axios.get(`http://localhost:4000/user/${order.userId}`).then((response)=>{
        let reviewObject = {
          UserName : response.data.userName
        }
      })
      axios.get(`http://localhost:5000/movie/${order.movieId}`).then((response)=>{
        reviewObject.MovieName = response.data.movieName
        // reviewObject.
      })
    }
  })
     
})	
  






module.exports = router
