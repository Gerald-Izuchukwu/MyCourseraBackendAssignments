
-- create a schema called `notesdb`

-- Create the tables for Note, Category, Reminder, NoteReminder and NoteCategory

-- Note table fields: note_id, note_title, note_content, note_status, note_creation_date
  
-- Category table fields : category_id, category_name, category_descr, category_creation_date

-- Reminder table fields : reminder_id, reminder_name, reminder_descr, reminder_type, reminder_creation_date

-- NoteCategory table fields : notecategory_id, note_id, category_id

-- NoteReminder table fields : notereminder_id, note_id, reminder_id

-- Execute all the queries in Mysql workbench 
