# 1. Get all the blogs created by user with id 17.

# 2. Update User ratings for user with id 10 to 5.

# 3. Remove all the documents created by user 80, since he has deleted his account.

# 4. Add a new column to all the documents for status as "ACTIVE" as default value for all.

# 5. Get all users with rating above and equal to 4.

# 6. Get all users with rating lesser to 4.

# 7. Update users with ratings more than 4 with tags as new field and value array of ["master", "created", "blogs"]

# 8. Find users have tags value "created" and "blogs"
