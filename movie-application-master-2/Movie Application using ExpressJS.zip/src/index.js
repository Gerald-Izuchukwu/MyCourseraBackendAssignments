const movieRouter = require("./movierouter");
    
// "axios": "^0.24.0",

module.exports = movieRouter;
